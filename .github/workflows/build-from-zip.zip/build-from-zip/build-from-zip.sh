#!/usr/bin/env bash
# Usage: ./build-from-zip.sh [path/to/phonebook-mod.zip] [output-folder]
# Unzips the project, builds it with Gradle (Java 21 needed), copies the jar next to this script.
set -euo pipefail

START="$(pwd)"
ZIP="${1:-phonebook-mod.zip}"
OUT="${2:-phonebook-build}"

command -v unzip >/dev/null || { echo "unzip is not installed"; exit 1; }
command -v java  >/dev/null || { echo "Java 21 is not installed"; exit 1; }
[ -f "$ZIP" ] || { echo "Zip not found: $ZIP"; exit 1; }

rm -rf "$OUT"
mkdir -p "$OUT"
unzip -q "$ZIP" -d "$OUT"

# descend into the single top-level folder if there is one
cd "$OUT"
if [ "$(ls -A | wc -l)" -eq 1 ] && [ -d "$(ls -A)" ]; then cd "$(ls -A)"; fi

if [ -f ./gradlew ]; then
  chmod +x ./gradlew
  ./gradlew build
elif command -v gradle >/dev/null; then
  gradle build
else
  echo "Neither ./gradlew nor gradle found. Install Gradle 8.8+ (or run: gradle wrapper --gradle-version 8.10.2)."
  exit 1
fi

cp build/libs/*.jar "$START/"
echo "Done. Jar copied to: $START"
