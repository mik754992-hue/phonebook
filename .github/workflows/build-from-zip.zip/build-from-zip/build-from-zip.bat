@echo off
rem Usage: build-from-zip.bat [path\to\phonebook-mod.zip]
rem Unzips the project, builds it with Gradle (Java 21 needed), copies the jar next to this script.
setlocal
set "START=%CD%"
set "ZIP=%~1"
if "%ZIP%"=="" set "ZIP=phonebook-mod.zip"
set "OUT=phonebook-build"

if not exist "%ZIP%" (
  echo Zip not found: %ZIP%
  exit /b 1
)
if exist "%OUT%" rmdir /s /q "%OUT%"
powershell -NoProfile -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%OUT%' -Force"
if errorlevel 1 exit /b 1

set "PROJ=%OUT%"
for /d %%D in ("%OUT%\*") do set "PROJ=%%D"
cd /d "%PROJ%"

if exist gradlew.bat (
  call gradlew.bat build
) else (
  call gradle build
)
if errorlevel 1 (
  echo Build failed. Make sure Java 21 and Gradle 8.8+ are installed.
  exit /b 1
)

copy /y build\libs\*.jar "%START%" >nul
echo Done. Jar copied to: %START%
endlocal
