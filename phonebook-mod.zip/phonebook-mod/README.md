# Phone Book (NeoForge 1.21.1)

Adds a **Phone Book** item. Right-click it to open a book where:

- every page is a **table** (Name | Number),
- contacts are **auto-sorted** alphabetically and grouped into **A–Z sections** (non-letters go under `#`),
- an **A–Z index bar** jumps straight to a section (letters with no contacts are greyed out),
- type a name and number at the bottom and press **Add** (or Enter); click **x** to delete a contact,
- scroll the mouse wheel or use **< >** to flip pages.

Contacts are stored on the item itself (a data component), so each book keeps its own list.

**Recipe:** Book + Redstone (shapeless).

## Building

Requires Java 21.

```bash
gradle wrapper --gradle-version 8.10.2   # once, to generate ./gradlew (optional)
./gradlew build                          # jar ends up in build/libs/
./gradlew runClient                      # test in a dev client
```

Pushing to GitHub also builds automatically: see `.github/workflows/build.yml`.
The jar is uploaded as a workflow artifact.

## Customising

- Mod id / name / version / package: `gradle.properties`
  (if you change `mod_group_id`, move the Java package folders to match).
- Table layout (rows per page, column positions): `client/PhoneBookScreen.java`.
- Limits (name length, number length, max contacts): `PhoneBookData.java`.
- Texture placeholder: `assets/phonebook/textures/item/phone_book.png`.
