package com.example.phonebook;

import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(PhoneBookMod.MOD_ID);

    public static final DeferredItem<PhoneBookItem> PHONE_BOOK =
            ITEMS.registerItem("phone_book", PhoneBookItem::new, new Item.Properties().stacksTo(1));

    private ModItems() {}
}
