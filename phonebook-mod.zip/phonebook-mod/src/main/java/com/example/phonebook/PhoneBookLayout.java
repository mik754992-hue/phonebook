package com.example.phonebook;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Splits the sorted contacts into table pages. Each page is a list of rows,
 * where a row is either a letter header or a contact. Rules:
 *  - a section header is never left alone at the bottom of a page,
 *  - if a section continues onto the next page, its letter is repeated "(cont.)".
 * No client-only imports here, so it is safe to load anywhere.
 */
public final class PhoneBookLayout {
    public record Row(boolean header, char letter, boolean continued, PhoneBookData.Entry entry) {
        static Row header(char letter, boolean continued) { return new Row(true, letter, continued, null); }
        static Row contact(PhoneBookData.Entry e) { return new Row(false, '\0', false, e); }
    }

    private final List<List<Row>> pages;
    private final Map<Character, Integer> firstPage;

    private PhoneBookLayout(List<List<Row>> pages, Map<Character, Integer> firstPage) {
        this.pages = pages;
        this.firstPage = firstPage;
    }

    public static PhoneBookLayout build(List<PhoneBookData.Entry> sorted, int rowsPerPage) {
        List<List<Row>> pages = new ArrayList<>();
        Map<Character, Integer> first = new HashMap<>();
        List<Row> cur = new ArrayList<>();
        char prev = '\0';

        for (PhoneBookData.Entry e : sorted) {
            char sec = PhoneBookData.sectionOf(e.name());
            boolean newSection = sec != prev;
            int needed = newSection ? 2 : 1;
            if (!cur.isEmpty() && cur.size() + needed > rowsPerPage) {
                pages.add(cur);
                cur = new ArrayList<>();
            }
            if (newSection) {
                first.put(sec, pages.size());
                cur.add(Row.header(sec, false));
            } else if (cur.isEmpty()) {
                cur.add(Row.header(sec, true));
            }
            cur.add(Row.contact(e));
            prev = sec;
        }
        if (!cur.isEmpty()) pages.add(cur);
        if (pages.isEmpty()) pages.add(List.of());
        return new PhoneBookLayout(pages, first);
    }

    public int pageCount() { return pages.size(); }
    public List<Row> page(int index) { return pages.get(index); }
    public boolean hasSection(char c) { return firstPage.containsKey(c); }
    public Integer firstPage(char c) { return firstPage.get(c); }
}
