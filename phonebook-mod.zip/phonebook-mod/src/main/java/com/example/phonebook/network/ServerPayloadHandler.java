package com.example.phonebook.network;

import com.example.phonebook.ModDataComponents;
import com.example.phonebook.PhoneBookData;
import com.example.phonebook.PhoneBookItem;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public final class ServerPayloadHandler {
    private ServerPayloadHandler() {}

    /** Runs on the server main thread. Never trust the client: re-validate everything. */
    public static void handleEdit(EditPhoneBookPayload payload, IPayloadContext ctx) {
        Player player = ctx.player();
        InteractionHand hand = payload.offHand() ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
        ItemStack stack = player.getItemInHand(hand);
        if (!(stack.getItem() instanceof PhoneBookItem)) return;

        String name = payload.name().trim();
        String number = payload.number().trim();
        if (name.isEmpty() || number.isEmpty()
                || name.length() > PhoneBookData.MAX_NAME
                || number.length() > PhoneBookData.MAX_NUMBER) return;

        PhoneBookData data = stack.getOrDefault(ModDataComponents.PHONE_BOOK.get(), PhoneBookData.EMPTY);
        PhoneBookData.Entry entry = new PhoneBookData.Entry(name, number);
        stack.set(ModDataComponents.PHONE_BOOK.get(), payload.add() ? data.with(entry) : data.without(entry));
    }
}
