package com.example.phonebook;

import java.util.function.Supplier;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModDataComponents {
    public static final DeferredRegister<DataComponentType<?>> COMPONENTS =
            DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, PhoneBookMod.MOD_ID);

    public static final Supplier<DataComponentType<PhoneBookData>> PHONE_BOOK =
            COMPONENTS.register("phone_book", () -> DataComponentType.<PhoneBookData>builder()
                    .persistent(PhoneBookData.CODEC)
                    .networkSynchronized(PhoneBookData.STREAM_CODEC)
                    .build());

    private ModDataComponents() {}
}
