package com.example.phonebook;

import com.example.phonebook.network.EditPhoneBookPayload;
import com.example.phonebook.network.ServerPayloadHandler;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

@Mod(PhoneBookMod.MOD_ID)
public class PhoneBookMod {
    public static final String MOD_ID = "phonebook";

    public PhoneBookMod(IEventBus modBus) {
        ModDataComponents.COMPONENTS.register(modBus);
        ModItems.ITEMS.register(modBus);
        modBus.addListener(this::registerPayloads);
        modBus.addListener(this::addToCreativeTab);
    }

    private void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(EditPhoneBookPayload.TYPE, EditPhoneBookPayload.STREAM_CODEC,
                ServerPayloadHandler::handleEdit);
    }

    private void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModItems.PHONE_BOOK.get());
        }
    }
}
