package com.example.phonebook;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

/**
 * The contacts stored on a phone book item.
 * The list is ALWAYS kept sorted (alphabetical sections, '#' last), so
 * anything that creates one - the GUI, /give, a datapack - gets auto-sorted.
 */
public record PhoneBookData(List<Entry> entries) {
    public static final int MAX_NAME = 24;
    public static final int MAX_NUMBER = 16;
    public static final int MAX_ENTRIES = 300;

    public record Entry(String name, String number) {
        public static final Codec<Entry> CODEC = RecordCodecBuilder.create(i -> i.group(
                Codec.STRING.fieldOf("name").forGetter(Entry::name),
                Codec.STRING.fieldOf("number").forGetter(Entry::number)
        ).apply(i, Entry::new));

        public static final StreamCodec<ByteBuf, Entry> STREAM_CODEC = StreamCodec.composite(
                ByteBufCodecs.STRING_UTF8, Entry::name,
                ByteBufCodecs.STRING_UTF8, Entry::number,
                Entry::new);
    }

    /** Section letter order: A-Z, then '#' (anything that isn't a Latin letter). */
    private static int sectionOrder(char c) {
        return c == '#' ? 'Z' + 1 : c;
    }

    public static final Comparator<Entry> ORDER = Comparator
            .<Entry>comparingInt(e -> sectionOrder(sectionOf(e.name())))
            .thenComparing(e -> e.name().toLowerCase(Locale.ROOT))
            .thenComparing(Entry::number);

    public static final PhoneBookData EMPTY = new PhoneBookData(List.of());

    public static final Codec<PhoneBookData> CODEC =
            Entry.CODEC.listOf().xmap(PhoneBookData::new, PhoneBookData::entries);

    public static final StreamCodec<ByteBuf, PhoneBookData> STREAM_CODEC =
            Entry.STREAM_CODEC.apply(ByteBufCodecs.list()).map(PhoneBookData::new, PhoneBookData::entries);

    public PhoneBookData {
        List<Entry> copy = new ArrayList<>(entries);
        copy.sort(ORDER);
        entries = List.copyOf(copy);
    }

    /** 'A'-'Z' for names starting with a letter (accents stripped), otherwise '#'. */
    public static char sectionOf(String name) {
        String n = Normalizer.normalize(name.trim(), Normalizer.Form.NFD);
        if (n.isEmpty()) return '#';
        char c = Character.toUpperCase(n.charAt(0));
        return (c >= 'A' && c <= 'Z') ? c : '#';
    }

    public PhoneBookData with(Entry entry) {
        if (entries.contains(entry) || entries.size() >= MAX_ENTRIES) return this;
        List<Entry> l = new ArrayList<>(entries);
        l.add(entry);
        return new PhoneBookData(l);
    }

    public PhoneBookData without(Entry entry) {
        List<Entry> l = new ArrayList<>(entries);
        l.remove(entry);
        return new PhoneBookData(l);
    }
}
