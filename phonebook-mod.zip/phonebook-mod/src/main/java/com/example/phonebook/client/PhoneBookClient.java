package com.example.phonebook.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;

/** Only ever called on the logical client, so Minecraft.getInstance() is safe here. */
public final class PhoneBookClient {
    private PhoneBookClient() {}

    public static void openScreen(InteractionHand hand) {
        Minecraft.getInstance().setScreen(new PhoneBookScreen(hand));
    }
}
