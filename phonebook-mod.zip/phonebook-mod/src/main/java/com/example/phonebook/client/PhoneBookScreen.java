package com.example.phonebook.client;

import com.example.phonebook.ModDataComponents;
import com.example.phonebook.PhoneBookData;
import com.example.phonebook.PhoneBookItem;
import com.example.phonebook.PhoneBookLayout;
import com.example.phonebook.network.EditPhoneBookPayload;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

public class PhoneBookScreen extends Screen {
    // ---- layout constants (tweak freely) ----
    private static final int W = 300;
    private static final int H = 218;
    private static final int ROWS_PER_PAGE = 9;   // header rows count as a row
    private static final int ROW_H = 12;
    private static final int COL_NAME_X = 16;     // relative to panel left
    private static final int COL_NUMBER_X = 176;

    private static final int INK = 0xFF3B2A1A;
    private static final String INDEX = "ABCDEFGHIJKLMNOPQRSTUVWXYZ#";

    private final InteractionHand hand;
    private PhoneBookData data;
    private PhoneBookLayout layout;
    private int page;
    private String nameText = "";
    private String numberText = "";
    private EditBox nameBox;
    private EditBox numberBox;
    private int left;
    private int top;

    public PhoneBookScreen(InteractionHand hand) {
        super(Component.translatable("item.phonebook.phone_book"));
        this.hand = hand;
        this.data = currentData();
    }

    private PhoneBookData currentData() {
        Player p = Minecraft.getInstance().player;
        if (p == null) return PhoneBookData.EMPTY;
        return p.getItemInHand(hand).getOrDefault(ModDataComponents.PHONE_BOOK.get(), PhoneBookData.EMPTY);
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        layout = PhoneBookLayout.build(data.entries(), ROWS_PER_PAGE);
        page = Mth.clamp(page, 0, layout.pageCount() - 1);

        // A-Z index bar
        int bx = left + (W - INDEX.length() * 10) / 2;
        for (int i = 0; i < INDEX.length(); i++) {
            final char c = INDEX.charAt(i);
            Button b = Button.builder(Component.literal(String.valueOf(c)), btn -> {
                Integer target = layout.firstPage(c);
                if (target != null) {
                    page = target;
                    rebuildWidgets();
                }
            }).bounds(bx + i * 10, top + 20, 10, 12).build();
            b.active = layout.hasSection(c);
            addRenderableWidget(b);
        }

        // delete buttons for this page's contacts
        List<PhoneBookLayout.Row> rows = layout.page(page);
        for (int i = 0; i < rows.size(); i++) {
            PhoneBookLayout.Row row = rows.get(i);
            if (row.header()) continue;
            PhoneBookData.Entry entry = row.entry();
            int y = top + 48 + i * ROW_H;
            addRenderableWidget(Button.builder(Component.literal("x"),
                            btn -> send(false, entry.name(), entry.number()))
                    .bounds(left + W - 28, y, 12, 11)
                    .tooltip(Tooltip.create(Component.translatable("gui.phonebook.remove")))
                    .build());
        }

        // add-contact row
        nameBox = new EditBox(font, left + 16, top + 168, 130, 14, Component.translatable("gui.phonebook.name"));
        nameBox.setMaxLength(PhoneBookData.MAX_NAME);
        nameBox.setHint(Component.translatable("gui.phonebook.name"));
        nameBox.setValue(nameText);
        nameBox.setResponder(s -> nameText = s);
        addRenderableWidget(nameBox);

        numberBox = new EditBox(font, left + 150, top + 168, 90, 14, Component.translatable("gui.phonebook.number"));
        numberBox.setMaxLength(PhoneBookData.MAX_NUMBER);
        numberBox.setHint(Component.translatable("gui.phonebook.number"));
        numberBox.setFilter(s -> s.matches("[0-9+\\-()\\s.*#]*"));
        numberBox.setValue(numberText);
        numberBox.setResponder(s -> numberText = s);
        addRenderableWidget(numberBox);

        addRenderableWidget(Button.builder(Component.translatable("gui.phonebook.add"), btn -> submit())
                .bounds(left + 244, top + 167, 40, 16).build());

        // page flipping
        Button prev = Button.builder(Component.literal("<"), btn -> changePage(-1))
                .bounds(left + 16, top + 192, 24, 16).build();
        prev.active = page > 0;
        addRenderableWidget(prev);
        Button next = Button.builder(Component.literal(">"), btn -> changePage(1))
                .bounds(left + W - 40, top + 192, 24, 16).build();
        next.active = page < layout.pageCount() - 1;
        addRenderableWidget(next);

        setInitialFocus(nameBox);
    }

    private void changePage(int delta) {
        int np = Mth.clamp(page + delta, 0, layout.pageCount() - 1);
        if (np != page) {
            page = np;
            rebuildWidgets();
        }
    }

    private void submit() {
        String n = nameText.trim();
        String num = numberText.trim();
        if (n.isEmpty() || num.isEmpty()) return;
        send(true, n, num);
        nameBox.setValue("");
        numberBox.setValue("");
    }

    private void send(boolean add, String name, String number) {
        PacketDistributor.sendToServer(
                new EditPhoneBookPayload(hand == InteractionHand.OFF_HAND, add, name, number));
    }

    @Override
    public void tick() {
        Player p = minecraft == null ? null : minecraft.player;
        if (p == null || !(p.getItemInHand(hand).getItem() instanceof PhoneBookItem)) {
            onClose();
            return;
        }
        PhoneBookData now = currentData();
        if (!now.equals(data)) {   // server confirmed a change -> redraw
            data = now;
            rebuildWidgets();
        }
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.renderBackground(g, mouseX, mouseY, partialTick);

        // paper + border
        g.fill(left - 2, top - 2, left + W + 2, top + H + 2, 0xFF3B2A1A);
        g.fill(left, top, left + W, top + H, 0xFFE9DFC3);

        // title
        Component title = getTitle();
        g.drawString(font, title, left + (W - font.width(title)) / 2, top + 7, INK, false);

        // table header
        g.fill(left + 10, top + 34, left + W - 10, top + 46, 0xFF6B4A2B);
        g.drawString(font, Component.translatable("gui.phonebook.name"), left + COL_NAME_X, top + 36, 0xFFFFFFFF, false);
        g.drawString(font, Component.translatable("gui.phonebook.number"), left + COL_NUMBER_X, top + 36, 0xFFFFFFFF, false);

        // table rows
        List<PhoneBookLayout.Row> rows = layout.page(page);
        if (rows.isEmpty()) {
            Component empty = Component.translatable("gui.phonebook.empty");
            g.drawString(font, empty, left + (W - font.width(empty)) / 2, top + 90, 0xFF7A6A55, false);
        }
        for (int i = 0; i < rows.size(); i++) {
            PhoneBookLayout.Row row = rows.get(i);
            int y = top + 48 + i * ROW_H;
            if (row.header()) {
                g.fill(left + 10, y, left + W - 10, y + ROW_H - 1, 0xFFC9B27A);
                String label = row.continued() ? row.letter() + " (cont.)" : String.valueOf(row.letter());
                g.drawString(font, Component.literal(label).withStyle(ChatFormatting.BOLD),
                        left + COL_NAME_X, y + 2, INK, false);
            } else {
                if (i % 2 == 0) {
                    g.fill(left + 10, y, left + W - 10, y + ROW_H - 1, 0x14000000);
                }
                g.drawString(font, font.plainSubstrByWidth(row.entry().name(), COL_NUMBER_X - COL_NAME_X - 4),
                        left + COL_NAME_X, y + 2, INK, false);
                g.drawString(font, row.entry().number(), left + COL_NUMBER_X, y + 2, INK, false);
            }
        }

        // divider above the add row
        g.fill(left + 10, top + 160, left + W - 10, top + 161, 0xFF6B4A2B);

        // page label
        Component label = Component.translatable("gui.phonebook.page", page + 1, layout.pageCount());
        g.drawString(font, label, left + (W - font.width(label)) / 2, top + 196, INK, false);
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        boolean enter = key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER;
        if (enter && (nameBox.isFocused() || numberBox.isFocused())) {
            if (nameBox.isFocused() && !nameText.trim().isEmpty() && numberText.trim().isEmpty()) {
                setFocused(numberBox);
            } else {
                submit();
            }
            return true;
        }
        return super.keyPressed(key, scanCode, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (scrollY != 0) {
            changePage(scrollY < 0 ? 1 : -1);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
