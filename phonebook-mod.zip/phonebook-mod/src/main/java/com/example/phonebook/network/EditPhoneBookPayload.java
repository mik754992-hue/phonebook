package com.example.phonebook.network;

import com.example.phonebook.PhoneBookMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client -> server: add or remove one contact in the book held in the given hand. */
public record EditPhoneBookPayload(boolean offHand, boolean add, String name, String number)
        implements CustomPacketPayload {

    public static final Type<EditPhoneBookPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(PhoneBookMod.MOD_ID, "edit"));

    public static final StreamCodec<ByteBuf, EditPhoneBookPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.BOOL, EditPhoneBookPayload::offHand,
            ByteBufCodecs.BOOL, EditPhoneBookPayload::add,
            ByteBufCodecs.STRING_UTF8, EditPhoneBookPayload::name,
            ByteBufCodecs.STRING_UTF8, EditPhoneBookPayload::number,
            EditPhoneBookPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
